## Perform the data visualization operations using Tableau to get answers to various business questions on Retail dataset.

1. Find and Plot country wise popular product
2. Find and Plot bottom 10 products based on total sale
3. Find and Plot top 5 purchase order
4. Find and Plot most popular products based on sales
5. Find and Plot half yearly sales for the year 2011
6. Find and Plot country wise total sales quantity and show on Geospatial graph
