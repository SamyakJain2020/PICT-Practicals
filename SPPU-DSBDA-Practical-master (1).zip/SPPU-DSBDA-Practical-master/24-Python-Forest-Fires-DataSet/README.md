## Perform the following operations using Python on Forest Fires Dataset.

1. Create data subsets by making classes for amount of region affected. (e.g. Not Affected, Partially affected, Mostly affected).
2. Merge two subsets
3. Sort Data using Temperature, wind and area.
4. Transposing Data
5. Melting Data to long format
6. Casting data to wide format
