## Perform the data visualization operations using Tableau to get answers to various business questions on Retail dataset.

1. Find and Plot top 10 products based on total sale
2. Find and Plot product contribution to total sale
3. Find and Plot the month wise sales in year 2010 in descending order
4. Find and Plot most loyal customers based on purchase order
5. Find and Plot yearly sales comparison
6. Find and Plot country wise total sales price and show on Geospatial graph
