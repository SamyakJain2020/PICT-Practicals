## Design and develop a distributed application to find frequency of words from sample text data. Use sample text data and process it using MapReduce.
