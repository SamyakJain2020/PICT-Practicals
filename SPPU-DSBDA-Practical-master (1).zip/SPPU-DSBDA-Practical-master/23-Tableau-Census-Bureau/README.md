## Perform the data visualization operations using Tableau to get answers to various questions on the census bureau data set(Adult data sets).

1. Find and Plot Income class of People whose education is master’s and doctorate.
2. Find and Plot Income class of people who have private jobs.
3. Find and Plot yearly sales comparison
4. Find and Plot country wise statistics on Geospatial graph
5. Plot age wise- education vs salary statistics.
6. Plot Country wise male female ratio.
7. Plot Income class based on workclass (Government and other)
