## Visualize the Heart disease dataset by plotting the following graphs using Python. (Define objective for every graph)

1. Histogram
2. Dot Plots
3. Bar Plots
4. Line Charts
5. Multivariate Analysis using Scatter Plots
