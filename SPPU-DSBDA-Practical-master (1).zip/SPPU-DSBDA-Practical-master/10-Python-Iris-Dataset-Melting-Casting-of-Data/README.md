## Perform the following operations using Python on the Iris data sets

1. Create data subsets for different species
2. Merge two subsets
3. Sort Data Petal Length
4. Transposing Data
5. Melting Data to long format
6. Casting data to wide format
