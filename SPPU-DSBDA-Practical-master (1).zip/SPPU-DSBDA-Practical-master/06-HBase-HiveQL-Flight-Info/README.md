## Write an application using HBase and HiveQL for flight information system which will include

1. Create Flight Info Hbase Table(with Flight information, schedule, and delay)
2. Demonstrate Creating, Dropping, and altering Database tables in Hbase
3. Creating an external Hive table to connect to the HBase for Flight Information Table
4. Find the total departure delay in Hive
5. Find the average departure delay in Hive
6. Create index on Flight information Table
