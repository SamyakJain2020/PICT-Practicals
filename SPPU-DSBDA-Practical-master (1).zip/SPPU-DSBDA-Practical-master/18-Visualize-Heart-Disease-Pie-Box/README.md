## Visualize the Heart disease dataset by plotting the following graphs using Python. (Define objective for every graph)

1. Histogram
2. Pie Charts
3. Box Plots
4. Scatter Plots
5. Bar Plot
