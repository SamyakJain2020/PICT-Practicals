## Perform the following operations using Python on Breast Cancer data sets

1. Data cleaning(Remove NA, ?, Negative values etc.)
2. Error correcting(Outlier detection and removal)
3. Data transformation
4. Build Data model using regression and Naïve Bayes methods and compare accuracy of benign and malignant tumors in Breast Cancer Dataset.
