## Perform the following operations using Python on Movie data sets

1. Create data subsets for different languages(Original Language)
2. Merge two subsets
3. Sort Data using customer ratings.
4. Transposing Data
5. Melting Data to long format
6. Casting data to wide format