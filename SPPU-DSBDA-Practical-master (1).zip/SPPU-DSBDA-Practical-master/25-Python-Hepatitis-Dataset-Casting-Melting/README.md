## Perform the following operations using Python on Hepatitis Dataset.

1. Create data subsets for different sex.
2. Merge two subsets
3. Sort Data using age, SGOT, PROTIME.
4. Transposing Data
5. Melting Data to long format
6. Casting data to wide format
