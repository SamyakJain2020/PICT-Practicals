## Write an application using HBase and HiveQL for Customer information system which will include

1. Creation of –Cutomer_info(Cust-ID,Cust-Name,orderID),order_info(OrderID,ItemID,Quantity), item_info(Item-ID,Item-Name,ItemPrice) tables in Hive
2. Load table with data from local storage in Hive.
3. Perform Join tables with Hive
4. Create Index on Customer information system in Hive.
5. Find the total, average sales in Hive
6. Find Order details with maximum cost.
7. Creating an external Hive table to connect to the HBase for Customer Information System.
8. Display records of Customer Information Table in Hbase.
